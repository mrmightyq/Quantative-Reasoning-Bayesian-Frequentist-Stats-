# Code for exercise related to sidebar 6.2
#install.packages("BEST")

library(BEST)
data(mtcars)

mean(mtcars$mpg)
sd(mtcars$mpg)
tapply(mtcars$mpg,mtcars$am,mean)
tapply(mtcars$mpg,mtcars$am,sd)

# Set the baseline: Uninformative priors, the default
carsBest2 <- BESTmcmc(mtcars$mpg[mtcars$am==0] ,mtcars$mpg[mtcars$am==1]) 
plot(carsBest2, main=NULL) 

# The code in the book's sidebar on pp 103-104
priorList <- list(muM = c(20,20), muSD = c(4,4))
carsBest2 <- BESTmcmc(mtcars$mpg[mtcars$am==0] ,mtcars$mpg[mtcars$am==1],priors=priorList) 
plot(carsBest2, main=NULL) 

# Reverse the means
priorList <- list(muM = c(24,17), muSD = c(4,4))
carsBest2 <- BESTmcmc(mtcars$mpg[mtcars$am==0] ,mtcars$mpg[mtcars$am==1],priors=priorList) 
plot(carsBest2, main=NULL) 

# Increase the SDs
priorList <- list(muM = c(24,17), muSD = c(6,6))
carsBest2 <- BESTmcmc(mtcars$mpg[mtcars$am==0] ,mtcars$mpg[mtcars$am==1],priors=priorList) 
plot(carsBest2, main=NULL) 

# Everything totally wrong
priorList <- list(muM = c(10,10), muSD = c(2,2))
carsBest2 <- BESTmcmc(mtcars$mpg[mtcars$am==0] ,mtcars$mpg[mtcars$am==1],priors=priorList) 
plot(carsBest2, main=NULL) 



# ANOVA Case Studies
library(BayesFactor)
set.seed(321)

# Scenario 1
DV <- runif(n=99,min=64,max=128)
IV <- as.factor(c(rep.int(1,33),rep.int(2,33),rep.int(3,33)))
dataFr1 <- data.frame(DV,IV)
boxplot(DV ~ IV, data=dataFr1)
aovOut <- aov(DV ~ IV, data=dataFr1)
summary(aovOut)

bayesOut <- anovaBF(DV ~ IV, data=dataFr1) # Calc Bayes Factors
mcmcOut <- posterior(bayesOut,iterations=10000)  # Run mcmc iterations
boxplot(as.matrix(mcmcOut[,2:4]), main=NULL)
summary(mcmcOut)
bayesOut

# Scenario 2
DV <- rnorm(n=99,mean=50,sd=10)
DV[67:99] <- DV[67:99] + 4
dataFr1 <- data.frame(DV,IV)
boxplot(DV ~ IV, data=dataFr1)
aovOut <- aov(DV ~ IV, data=dataFr1)
summary(aovOut)

bayesOut <- anovaBF(DV ~ IV, data=dataFr1) # Calc Bayes Factors
mcmcOut <- posterior(bayesOut,iterations=10000)  # Run mcmc iterations
boxplot(as.matrix(mcmcOut[,2:4]), main=NULL)
summary(mcmcOut)
bayesOut
